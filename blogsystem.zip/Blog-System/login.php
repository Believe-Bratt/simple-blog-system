<?php
include 'includes/db_connect.php';
include 'includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password']; 
    $error ="";

    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) { 
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            if ($user['role'] == 'admin') {
                header('Location: admin/dashboard.php');
            } else {
                header('Location: public/index.php');
            }
        } else {
            $error= "Invalid password.";
        }
    } else {
        $error = "No user found with that username.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/form.css">
    <script src="js/form_validation.js"></script>
    <title>Log in</title>
</head>
<body>
<div class="animated-text">BELIEVE TECKK</div>
    <div class="container">
        <div class="form-container">
        <div class="form-toggle">
              <a href="register.php"><button id="loginBtn" class="active-toggle">Register</button></a>
                <button id="signupBtn">Login</button>
            </div>
            <form id="loginForm" class="form active-form" method="POST" action="login.php">
                <h2>Login</h2>
                <?php if(isset($error)){?>
        <p id="error"><?php echo $error; ?></p>
       <?php } ?>
                <div class="input-group">
                    <label for="loginName">Name</label>
                    <input type="text" id="loginName" name="username">
                </div>
                <div class="input-group">
                    <label for="loginPassword">Password</label>
                    <input type="password" id="loginPassword" name="password">
                </div>
                <p>Not having an Account? Click <a href="register.php">here</a></p>
                <button type="submit" class="btn">Login</button>
            </form>
        </div>
    </div>
 
</body>
</html>

