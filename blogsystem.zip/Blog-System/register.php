<?php
include 'includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $error ="";
    $success ="";
    
    if($username !== "" && $password !=="" && $email !=="" ){
     
     $sql = " INSERT INTO `users`( `username`, `password`, `email`, `role`) VALUES ('$username','$password','$email','user')";
         if ($conn -> query($sql) === TRUE){
           $success = "You have successful Registered an account enjoy!" ;
         } else{
            $error = '<br>ERROR '.$sql . '  '. $conn -> error;
         }
    }else{
        $error="All areas must filled properly!";
    }   
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/form.css">
    <title>Registration</title>
</head>
<body>
<div class="animated-text">BELIEVE TECKK</div>
    <div class="container">
        <div class="form-container">
        <div class="form-toggle">
              <a href="login.php"><button id="loginBtn" class="active-toggle">Login</button></a>
                <button id="signupBtn">Register</button>
            </div>
            <form id="loginForm" class="form active-form" method="POST" action="register.php">
                <h2>Create an account</h2>
                <?php if(isset($error)){?>
        <p id="error"><?php echo $error; ?></p>
       <?php } ?>
       <?php if(isset($success)){?>
        <p id="success"><?php echo $success; ?></p>
       <?php } ?>
                <div class="input-group">
                    <label for="loginName">Name</label>
                    <input type="text" id="loginName" name="username">
                </div>
                <div class="input-group">
                    <label for="loginEmail">Email</label>
                    <input type="text" id="loginEmail" name="email">
                </div>
                <div class="input-group">
                    <label for="loginPassword">Password</label>
                    <input type="password" id="loginPassword" name="password">
                </div>
                <div class="input-group">
                    <label for="loginPassword">Confirm Password</label>
                    <input type="password" id="loginPassword" name="confirmPassword">
                </div>
                <p>Already having an Account? Click <a href="login.php">here</a></p>
                <button type="submit" class="btn">Register</button>
            </form>
        </div>
    </div>
 
</body>
</html>

