<?php
include '../includes/db_connect.php';
include '../includes/auth.php';

redirect_if_not_logged_in('admin');

$post_id = $_GET['id'];
$post_query = $conn->query("SELECT * FROM posts WHERE id = '$post_id'");
if ($post_query->num_rows == 0) {
    echo "Post not found.";
    exit();
}
$post = $post_query->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);
    $author_id = $_SESSION['user_id'];
    $category_id = $_POST['category_id'];
    $tags = $_POST['tags']; // Tags should be a comma-separated string

    $target_dir = "../images";
    $target_file = $target_dir . basename($_FILES["featured_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if (!empty($_FILES["featured_image"]["tmp_name"])) {
        $check = getimagesize($_FILES["featured_image"]["tmp_name"]);
        if ($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }

        if ($_FILES["featured_image"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        if ($uploadOk == 1) {
            if (move_uploaded_file($_FILES["featured_image"]["tmp_name"], $target_file)) {
                echo "The file " . htmlspecialchars(basename($_FILES["featured_image"]["name"])) . " has been uploaded.";
                $featured_image_path = $target_file;
            } else {
                echo "Sorry, there was an error uploading your file.";
                $uploadOk = 0;
            }
        }
    } else {
        $featured_image_path = $post['featured_image'];
    }

    if ($uploadOk == 1) {
        $sql = "UPDATE posts SET title = '$title', content = '$content', category_id = '$category_id', featured_image = '$featured_image_path' WHERE id = '$post_id'";
        if ($conn->query($sql) === TRUE) {
            // Update tags
            $conn->query("DELETE FROM post_tags WHERE post_id = '$post_id'");
            $tags_array = explode(',', $tags);
            foreach ($tags_array as $tag) {
                $tag = trim($tag);
                if (!empty($tag)) {
                    $tag_query = $conn->query("SELECT id FROM tags WHERE name = '$tag'");
                    if ($tag_query->num_rows == 0) {
                        $conn->query("INSERT INTO tags (name) VALUES ('$tag')");
                        $tag_id = $conn->insert_id;
                    } else {
                        $tag_id = $tag_query->fetch_assoc()['id'];
                    }
                    $conn->query("INSERT INTO post_tags (post_id, tag_id) VALUES ('$post_id', '$tag_id')");
                }
            }
            header('Location: dashboard.php');
            exit();
        } else {
            echo "Error updating post: " . $conn->error;
        }
    }
}

$categories_query = $conn->query("SELECT * FROM categories");
$tags_query = $conn->query("SELECT t.name FROM tags t JOIN post_tags pt ON t.id = pt.tag_id WHERE pt.post_id = '$post_id'");
$existing_tags = [];
while ($tag = $tags_query->fetch_assoc()) {
    $existing_tags[] = $tag['name'];
}
$existing_tags_str = implode(', ', $existing_tags);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>
    <h1>Edit Post</h1>
    <form method="POST" action="edit_post.php?id=<?= $post_id ?>" enctype="multipart/form-data">
        <label>Title: <input type="text" name="title" value="<?= htmlspecialchars($post['title']) ?>" required></label><br>
        <label>Content: <textarea name="content" required><?= htmlspecialchars($post['content']) ?></textarea></label><br>
        <label>Category:
            <select name="category_id" required>
                <?php while ($category = $categories_query->fetch_assoc()): ?>
                <option value="<?= $category['id'] ?>" <?= $category['id'] == $post['category_id'] ? 'selected' : '' ?>><?= $category['name'] ?></option>
                <?php endwhile; ?>
            </select>
        </label><br>
        <label>Tags: <input type="text" name="tags" placeholder="Comma separated tags"></label><br>
        <label>Featured Image: <input type="file" name="featured_image"></label><br>
        <?php if ($post['featured_image']): ?>
            <img src="<?= htmlspecialchars($post['featured_image']) ?>" alt="Featured Image" width="100"><br>
        <?php endif; ?>
        <button type="submit">Update Post</button>
        <a href="javascript:history.go(-1)" class="back-button">Back</a>
    </form>
</body>
</html>
