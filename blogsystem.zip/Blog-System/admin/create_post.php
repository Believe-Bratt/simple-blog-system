<?php
include '../includes/db_connect.php';
include '../includes/auth.php';

redirect_if_not_logged_in('admin'); 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $author_id = $_SESSION['user_id'];
    $category_id = $_POST['category_id'];
    $tag_ids = $_POST['tag_ids']; 

    
    $target_dir = "../images";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        echo "The file " . htmlspecialchars(basename($_FILES["image"]["name"])) . " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }

    $stmt = $conn->prepare("INSERT INTO posts (title, content, author_id, category_id, featured_image) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param('ssiss', $title, $content, $author_id, $category_id, $target_file);

    if ($stmt->execute()) {
        $post_id = $stmt->insert_id;
        
        $stmt_tag = $conn->prepare("INSERT INTO post_tags (post_id, tag_id) VALUES (?, ?)");
        foreach ($tag_ids as $tag_id) {
            $stmt_tag->bind_param('ii', $post_id, $tag_id);
            $stmt_tag->execute();
        }

        header('Location: dashboard.php');
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}

$categories = $conn->query("SELECT * FROM categories");
$tags = $conn->query("SELECT * FROM tags");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Post</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>
    <h1>Create Post</h1>
    <form method="POST" action="create_post.php" enctype="multipart/form-data">
        <label>Title: <input type="text" name="title" required></label><br>
        <label>Content: <textarea name="content" required></textarea></label><br>
        <label>Category:
            <select name="category_id" required>
                <?php while ($category = $categories->fetch_assoc()): ?>
                    <option value="<?= $category['id'] ?>"><?= $category['name'] ?></option>
                <?php endwhile; ?>
            </select>
        </label><br>
        <label>Tags:
            <select name="tag_ids[]" multiple required>
                <?php while ($tag = $tags->fetch_assoc()): ?>
                    <option value="<?= $tag['id'] ?>"><?= $tag['name'] ?></option>
                <?php endwhile; ?>
            </select>
        </label><br>
        <label>Image: <input type="file" name="image" required></label><br>
        <button type="submit">Create Post</button>
        <a href="javascript:history.go(-1)" class="back-button">Back</a>

    </form>
</body>
</html>
