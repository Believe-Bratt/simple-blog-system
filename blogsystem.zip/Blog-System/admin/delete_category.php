<?php
include '../includes/db_connect.php';
include '../includes/auth.php';

redirect_if_not_logged_in('admin');

$category_id = $_GET['id'];
$sql = "DELETE FROM categories WHERE id = '$category_id'";

if ($conn->query($sql) === TRUE) {
    header('Location: manage_categories.php');
} else {
    echo "Error: " . $conn->error;
}
?>
