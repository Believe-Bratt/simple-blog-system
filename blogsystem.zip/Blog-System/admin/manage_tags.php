<?php
include '../includes/db_connect.php';
include '../includes/auth.php';

redirect_if_not_logged_in('admin');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $sql = "INSERT INTO tags (name) VALUES ('$name')";
    if ($conn->query($sql) === TRUE) {
        header('Location: manage_tags.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$tags = $conn->query("SELECT * FROM tags");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Tags</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>
    <h1>Manage Tags</h1>
    <form method="POST" action="manage_tags.php">
        <label>Tag Name: <input type="text" name="name" required></label><br>
        <button type="submit">Add Tag</button>
    </form>

    <h2>Existing Tags</h2>
    <ul>
        <?php while ($tag = $tags->fetch_assoc()): ?>
        <li><?= $tag['name'] ?> <a href="delete_tag.php?id=<?= $tag['id'] ?>">Delete</a></li>
        <?php endwhile; ?>
    </ul>
    <a href="javascript:history.go(-1)" class="back-button">Back</a>

</body>
</html>
