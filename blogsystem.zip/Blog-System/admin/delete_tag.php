<?php
include '../includes/db_connect.php';
include '../includes/auth.php';

redirect_if_not_logged_in('admin');

$tag_id = $_GET['id'];
$sql = "DELETE FROM tags WHERE id = '$tag_id'";

if ($conn->query($sql) === TRUE) {
    header('Location: manage_tags.php');
} else {
    echo "Error: " . $conn->error;
}
?>
