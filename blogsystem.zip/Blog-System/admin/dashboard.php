<?php
include '../includes/db_connect.php';
include '../includes/auth.php';

redirect_if_not_logged_in('admin');

$posts = $conn->query("SELECT p.*, u.username FROM posts p JOIN users u ON p.author_id = u.id ORDER BY p.created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../styles/dashboard.css">
</head>
<body>
    <h1>Admin Dashboard</h1>
    <a href="create_post.php">Create New Post</a>
    <table>
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Created At</th>
            <th>Actions</th>
        </tr>
        <?php while ($post = $posts->fetch_assoc()): ?>
        <tr>
            <td><?= $post['title'] ?></td>
            <td><?= $post['username'] ?></td>
            <td><?= $post['created_at'] ?></td>
            <td>
                <a href="edit_post.php?id=<?= $post['id'] ?>">Edit</a>
                <a href="delete_post.php?id=<?= $post['id'] ?>">Delete</a>
                <?php if ($post['published']): ?>
                    <a href="unpublish_post.php?id=<?= $post['id'] ?>">Unpublish</a>
                <?php else: ?>
                    <a href="publish_post.php?id=<?= $post['id'] ?>">Publish</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <br><a href="manage_categories.php" class="back-button">manage categories</a>
    <br><a href="manage_tags.php"  class="button">Manage tags</a>

</body>
</html>
