<?php
include '../includes/db_connect.php';
include '../includes/auth.php';

redirect_if_not_logged_in('admin');

$post_id = $_GET['id'];
$sql = "UPDATE posts SET published = 1 WHERE id = '$post_id'";

if ($conn->query($sql) === TRUE) {
    header('Location: dashboard.php');
} else {
    echo "Error: " . $conn->error;
}
?>
