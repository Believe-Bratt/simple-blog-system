<?php
include '../includes/db_connect.php';
include '../includes/auth.php';

redirect_if_not_logged_in('admin');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $sql = "INSERT INTO categories (name) VALUES ('$name')";
    if ($conn->query($sql) === TRUE) {
        header('Location: manage_categories.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$categories = $conn->query("SELECT * FROM categories");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>
    <h1>Manage Categories</h1>
    <form method="POST" action="manage_categories.php">
        <label>Category Name: <input type="text" name="name" required></label><br>
        <button type="submit">Add Category</button>
    </form>

    <h2>Existing Categories</h2>
    <ul>
        <?php while ($category = $categories->fetch_assoc()): ?>
        <li><?= $category['name'] ?> <a href="delete_category.php?id=<?= $category['id'] ?>">Delete</a></li>
        <?php endwhile; ?>
    </ul>
    <a href="javascript:history.go(-1)" class="back-button">Back</a>

</body>
</html>

