-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2024 at 04:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Business'),
(4, 'Fashion'),
(2, 'Lifestyle'),
(6, 'Music'),
(5, 'News'),
(3, 'Sport');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment_text` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `comment_text`, `created_at`) VALUES
(1, 2, 4, 'Hello', '2024-06-29 08:11:52');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `featured_image` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `published` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `author_id`, `category_id`, `featured_image`, `created_at`, `updated_at`, `published`) VALUES
(1, '5 Things to consider when building your crypto currency portfolio', 'If you’ve decided that now is the time to invest in crypto, you may still be a little unsure of how to go about it. \r\n\r\nAdvertisement\r\n\r\nThe good news is the fundamentals of investing apply in the world of digital currency, just as they would if you were building a traditional investment portfolio. \r\n\r\nIf you were making your first foray into traditional investment, you’d take care to research all the assets that took your interest; you’d think carefully about how much risk you are prepared to carry, and you’d probably ask an expert for guidance. “Today, the traditional financial system remains a key gateway for participation in the crypto ecosystem through fiat on and off-ramps. It allows users to participate in the crypto economy and transfer their funds safely to their bank accounts and currency of choice when needed. \r\n\r\nIn other words, the two financial systems are not mutually exclusive but operate in synergy to serve users’ various needs.” General Manager of South Africa, Hannes Wessels said.\r\n\r\n1. What type of investor are you?\r\nIt’s important to ask yourself this question, because it’s going to determine the amount you are prepared to invest as well as your strategy. For example, if you’re simply curious about crypto and how the world of cybercurrency works, you’ll be far more cautious in your investments than if you have already done plenty of research, maybe purchased some altcoins and already seen a few market dips.\r\n\r\n2. Which crypto currency is for you?\r\nDid you know that Binance has 350+ cryptocurrencies? Obviously, that’s a lot to research individually – which means that most people may opt for the better known currencies, like Bitcoin or Ethereum. There’s nothing wrong with that – but remember that there are other alt coins that offer interesting returns if you are prepared to give them time. \r\n\r\nAs a general rule, any social media hype should be disregarded in favour of solid research – and you may also want to hang onto some healthy skepticism when it comes to cryptos that seem to have a high novelty value (alt-coins based on a TV series come to mind here). \r\n\r\n3. What’s your risk appetite?\r\nLegacy coins (think Bitcoin) are more prone to price fluctuations but, on the other hand, they’re not going to devalue spontaneously, making them a sound choice for people with a medium risk appetite. \r\n\r\nIf, on the other hand, you really don’t mind going for a complete wild card, you could invest in one of the newer currencies available. \r\n\r\nUsually associated with a specific platform, these currencies have been known to generate enormous gains – but it’s not uncommon for them to become suddenly worthless, either. \r\n\r\nThe best approach? It’s a good idea to spread your risk, just as you would with a traditional portfolio.\r\n\r\n4. What does your greater investment portfolio look like?\r\nBack to the premise of keeping your eggs safe by refusing to put them all in one basket - this sentiment holds true here, too. It’s always a good idea to diversify your investments, so consider your crypto assets just one part of a broader portfolio. Just how much of that portfolio should crypto account for? Up to you – but, in general terms, a 1-5 per cent allocation to the asset class is ideal for low risk investors, while those with medium risk appetites may want to up it all the way to 15 per cent. Remember that, as with any investment, a long-term outlook is key.\r\n\r\n5. Have you done your research?\r\nYou wouldn’t play the stock exchange without tracking the trends of corporate companies first, or at least finding out a little more about them. Maintain that principle when you invest in cybercurrencies, too. Read up as much as you can to make sure you have a thorough grasp of the risks involved, and get a little expert advice, too. - Binance.com. ', 5, 1, '../imagescrypto.jpeg', '2024-06-29 06:57:45', '2024-06-29 07:02:25', 1),
(2, 'Checkout Stonebwoys drip for the Paris Fashion Week', 'Stonebwoy, the celebrated Ghanaian artist, once again turned heads at Paris Fashion Week, not just with his music but with his impeccable fashion sense.\r\n1. Casual meets classic: For his first appearance, Stonebwoy opted for a laid-back yet stylish look. He wore a faded blue jean jacket over a large white buttoned shirt, paired with wide-legged jeans trousers.\r\n\r\nThis ensemble perfectly encapsulated a blend of comfort and style, showcasing his ability to merge classic denim wear with a modern twist. The outfit not only reflected his personal style but also resonated with the casual chic trend prevalent in today’s fashion streets.\r\n2. Bold and edgy: Stonebwoy’s second outfit was a bold statement in itself. He sported a vibrant red jacket over black cargo pants, accessorized with silver necklaces.\r\n\r\nThis look was all about making a statement while maintaining an edge that is often seen in street-style fashion. The red jacket served as the centerpiece, capturing attention and illustrating his fearless approach to color and style.\r\n3. Sophisticated playfulness: In his third change of wardrobe, Stonebwoy showcased a more playful yet sophisticated side. He wore a crochet white romper under a grey jacket, accessorized with a golden necklace and dark shades.\r\n\r\nThis outfit blended playful textures and sophisticated layers, creating a visually appealing look that stood out for its elegance and uniqueness.\r\n\r\nEach of these outfits not only highlighted Stonebwoy’s fashion-forward mentality but also his understanding of how to effectively present himself in the global fashion arena.\r\n\r\nHis choices are a testament to his personal brand, one that aligns seamlessly with the dynamic and evolving world of fashion. At Paris Fashion Week, Stonebwoy didn’t just wear clothes; he wore confidence and charisma, making each outfit a part of his vibrant lifestyle narrative.\r\n\r\nThrough his fashion, Stonebwoy communicates his artistic vision, proving that style at such high-profile events is as much about self-expression as it is about aesthetics.', 5, 4, '../imagesstonebow.jpg', '2024-06-29 07:02:22', '2024-06-29 07:02:27', 1),
(3, 'Croatia vs Italy LIVE! Euro 2024 result, match stream, latest updates today', 'jjdjiure dsrdkjrbfdkjkjrhjd', 5, 6, '../imagesWhatsApp Image 2024-06-23 at 05.20.18_08bf6309.jpg', '2024-06-29 08:39:11', '2024-06-29 21:03:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post_tags`
--

CREATE TABLE `post_tags` (
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`) VALUES
(3, 'Education'),
(2, 'Entrepreneurship'),
(7, 'Food'),
(4, 'Health'),
(8, 'Life'),
(6, 'Love'),
(1, 'Politics'),
(5, 'Technology');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `created_at`) VALUES
(1, 'Brat', 'admin@2', 'e@gmail.com', 'admin', '2024-06-29 05:57:51'),
(2, 'Bratt', '$2y$10$YSV9eJae6rnMawRMZ2qezuCg/zbgT5KnD5tRkFvEnq.8KzTDffNtO', '', 'user', '2024-06-29 06:25:48'),
(4, 'hcctechnical', '$2y$10$P8hIN3OviZYcNd4zVwp42eFgeNavvMdLhLuX8Ue.Znt9eqGE1RDfa', 'brat@gmail.com', 'user', '2024-06-29 06:32:02'),
(5, 'Believe', '$2y$10$g1v7G88RxZHwBoWVilDgxOS6AsDZ3rxf/9Eqn/JphkKYlNdYRTf.y', 'nana@gmail.com', 'admin', '2024-06-29 06:34:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `post_tags`
--
ALTER TABLE `post_tags`
  ADD PRIMARY KEY (`post_id`,`tag_id`),
  ADD KEY `tag_id` (`tag_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `post_tags`
--
ALTER TABLE `post_tags`
  ADD CONSTRAINT `post_tags_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  ADD CONSTRAINT `post_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
