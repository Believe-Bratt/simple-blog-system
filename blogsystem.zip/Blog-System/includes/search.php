<?php

$search = isset($_GET['search']) ? $_GET['search'] : '';
$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : '';
$tag_id = isset($_GET['tag_id']) ? $_GET['tag_id'] : '';

$query = "SELECT p.*, u.username FROM posts p JOIN users u ON p.author_id = u.id WHERE p.published = 1";

if ($search) {
    $query .= " AND (p.title LIKE '%$search%' OR p.content LIKE '%$search%')";
}

if ($category_id) {
    $query .= " AND p.category_id = '$category_id'";
}

if ($tag_id) {
    $query .= " AND EXISTS (SELECT 1 FROM post_tags pt WHERE pt.post_id = p.id AND pt.tag_id = '$tag_id')";
}

$query .= " ORDER BY p.created_at DESC";

$posts = $conn->query($query);
$categories = $conn->query("SELECT * FROM categories");
$tags = $conn->query("SELECT * FROM tags");
?>