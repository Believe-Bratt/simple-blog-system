<?php


session_start();


function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    return is_logged_in() && $_SESSION['role'] === 'admin';
}

function is_author() {
    return is_logged_in() && $_SESSION['role'] === 'author';
}

function redirect_if_not_logged_in($role = null) {
    if (!is_logged_in() || ($role && $_SESSION['role'] !== $role)) {
        header('Location: login.php');
        exit();
    }
    if ($role && $_SESSION['role'] !== $role) {
        header('Location: ../index.php'); 
        exit();
    }
}
?>
