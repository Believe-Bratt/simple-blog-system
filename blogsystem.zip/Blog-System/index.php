<?php
include 'includes/auth.php';

$role = 'user' || $role ='admin';

if (!is_logged_in() || ($role && $_SESSION['role'] !== $role)) {
    header('Location: public/index.php');
    exit();
}
?>