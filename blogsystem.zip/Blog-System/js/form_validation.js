document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById('signupForm');
    const loginForm = document.getElementById('loginForm');

    if (signupForm) {
        registerForm.addEventListener('submit', (e) => {
            const password = document.getElementsByName('password').value;
            const confirmPassword = document.getElementsByName('confirmPassword').value;
            const username = document.getElementById('signupName').value;

            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
            }
        }); if(!username || !password){
            e.preventDefault();
            alert('please fill in both form');
        }
    }

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            const username = document.getElementById('loginName').value;
            const password = document.getElementById('loginPassword').value;

            if (!username || !password) {
                e.preventDefault();
                alert('Please fill in both fields.');
            }
        });
    }
});
