// js/ajax_comments.js

document.addEventListener("DOMContentLoaded", function() {
    const commentForm = document.getElementById("commentForm");

    if (commentForm) {
        commentForm.addEventListener("submit", function(event) {
            event.preventDefault();

            const formData = new FormData(commentForm);
            const post_id = formData.get("post_id");

            fetch("add_comment.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Add the new comment to the comment section
                    const commentSection = document.getElementById("comments");
                    const newComment = document.createElement("div");
                    newComment.classList.add("comment");
                    newComment.innerHTML = `<p><strong>${data.username}</strong> (${data.created_at}): ${formData.get("comment_text")}</p>`;
                    commentSection.appendChild(newComment);
                    commentForm.reset();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => console.error('Error:', error));
        });
    }
});
