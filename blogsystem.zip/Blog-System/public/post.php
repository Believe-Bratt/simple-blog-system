<?php
include '../includes/db_connect.php';

if (isset($_GET['id'])) {
    $post_id = $_GET['id'];
    $post = $conn->query("SELECT p.*, u.username FROM posts p JOIN users u ON p.author_id = u.id WHERE p.id = '$post_id'")->fetch_assoc();
    if (!$post || !$post['published']) {
        header('Location: index.php');
        exit();
    }
} else {
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $post['title'] ?></title>
    <link rel="stylesheet" href="../styles/styles.css">
    <script src="../js/ajax_comments.js" defer></script>
</head>
<body>
<a href="javascript:history.go(-1)" class="back-button">Back</a>


    <h1><?= $post['title'] ?></h1>
    <p><strong>Author:</strong> <?= $post['username'] ?></p>
    <p><?= $post['created_at'] ?></p>
    <?php if ($post['featured_image']): ?>
    <img src="<?= $post['featured_image'] ?>" alt="<?= $post['title'] ?>">
    <?php endif; ?>
    <p><?= $post['content'] ?></p>
    <div id="comments">
        <h2>Comments</h2>
        <?php
        $comments = $conn->query("SELECT c.*, u.username FROM comments c JOIN users u ON c.user_id = u.id WHERE c.post_id = '$post_id' ORDER BY c.created_at DESC");
        while ($comment = $comments->fetch_assoc()): ?>
            <div class="comment">
                <p><strong><?= $comment['username'] ?></strong> (<?= $comment['created_at'] ?>): <?= $comment['comment_text'] ?></p>
            </div>
        <?php endwhile; ?>
        <?php if (isset($_SESSION['user_id'])): ?>
        <h3>Add Comment</h3>
        <form id="commentForm" method="POST" action="add_comment.php">
            <input type="hidden" name="post_id" value="<?= $post_id ?>">
            <textarea name="comment_text" required></textarea><br>
            <button type="submit">Add Comment</button>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
