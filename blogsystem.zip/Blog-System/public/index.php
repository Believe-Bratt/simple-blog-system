<?php
include '../includes/db_connect.php';
include '../includes/auth.php';

$posts = $conn->query("SELECT p.*, u.username FROM posts p JOIN users u ON p.author_id = u.id WHERE p.published = 1 ORDER BY p.created_at DESC");

// Fetch categories and tags
$categories = $conn->query("SELECT * FROM categories");
$tags = $conn->query("SELECT * FROM tags");

// Fetch posts based on category or tag filter
$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : null;
$tag_id = isset($_GET['tag_id']) ? $_GET['tag_id'] : null;
$search_query = '';
if (isset($_GET['search'])) {
    $search_query = $_GET['search'];
    $posts = $conn->query("SELECT p.*, u.username FROM posts p JOIN users u ON p.author_id = u.id WHERE p.published = 1 AND (p.title LIKE '%$search_query%' OR p.content LIKE '%$search_query%') ORDER BY p.created_at DESC");
}

$where_clause = "p.published = 1";
if ($category_id) {
    $where_clause .= " AND p.category_id = $category_id";
}
if ($tag_id) {
    $where_clause .= " AND p.id IN (SELECT post_id FROM post_tags WHERE tag_id = $tag_id)";
}
if ($search_query) {
    $where_clause .= " AND (p.title LIKE '%$search_query%' OR p.content LIKE '%$search_query%')";
}

$posts = $conn->query("SELECT p.*, u.username FROM posts p JOIN users u ON p.author_id = u.id WHERE $where_clause ORDER BY p.created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog System</title>
    <link rel="stylesheet" href="../styles/index.css">
    <script src="../js/ajax_comments.js" defer></script>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <ul>
            <li><a href="index.php">Believe Teckk</a></li>
            <?php while ($category = $categories->fetch_assoc()): ?>
                <li><a href="index.php?category_id=<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></a></li>
            <?php endwhile; ?>
            <li>
                <form class="search-form" method="GET" action="index.php">
                    <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($search_query) ?>">
                    <button type="submit">Search</button>
                </form>
            </li>
            <?php if (!isset($_SESSION['user_id'])): ?>
                <li style="margin-left: auto;"><a href="../login.php">Login</a></li>
            <?php else: ?>
                <li style="margin-left: auto;"><a href="../logout.php">Logout</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <!-- Content Section -->
    <div class="conten">
            <h1>Welcome to our blog system, explore more news and contents</h1>
    </div>
    
    <div class="container">    
        <div class="content">
            <div id="posts">
                <?php while ($post = $posts->fetch_assoc()): ?>
                <div class="post">
                    <h2><?= htmlspecialchars($post['title']) ?></h2>
                    <p><strong>Author:</strong> <?= htmlspecialchars($post['username']) ?></p>
                    <p><?= htmlspecialchars($post['created_at']) ?></p>
                    <?php if ($post['featured_image']): ?>
                    <img src="<?= htmlspecialchars($post['featured_image']) ?>" alt="<?= htmlspecialchars($post['title']) ?>">
                    <?php endif; ?>
                    <p><?= htmlspecialchars(substr($post['content'], 0, 200)) ?>...</p>
                    <a href="post.php?id=<?= $post['id'] ?>">Read more...</a>
                    <div id="comments-<?= $post['id'] ?>" class="comments">
                        <h3>Comments</h3>
                        <?php
                        $post_id = $post['id'];
                        $comments = $conn->query("SELECT c.*, u.username FROM comments c JOIN users u ON c.user_id = u.id WHERE c.post_id = '$post_id' ORDER BY c.created_at DESC");
                        while ($comment = $comments->fetch_assoc()): ?>
                            <div class="comment">
                                <p><strong><?= htmlspecialchars($comment['username']) ?>:</strong><br> <?= htmlspecialchars($comment['comment_text']) ?><br> <?= htmlspecialchars($comment['created_at']) ?></p>
                            </div>
                        <?php endwhile; ?>
                        
                        <?php if (isset($_SESSION['user_id'])): ?>
                        <h3>Add Comment</h3>
                        <form class="commentForm" method="POST" action="../add_comment.php" data-post-id="<?= $post_id ?>">
                            <input type="hidden" name="post_id" value="<?= $post_id ?>">
                            <textarea name="comment_text" required></textarea><br>
                            <button type="submit">Add Comment</button>
                        </form>
                        <?php else: ?>
                        <p><a href="../login.php">Login</a> to add a comment.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>

        <!-- Sidebar Section -->
        <div class="sidebar">
            <h3>Categories</h3>
            <ul>
                <?php
                $categories->data_seek(0); // Reset pointer to the beginning
                while ($category = $categories->fetch_assoc()): ?>
                    <li><a href="index.php?category_id=<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></a></li>
                <?php endwhile; ?>
            </ul>

            <h3>Tags</h3>
            <ul>
                <?php while ($tag = $tags->fetch_assoc()): ?>
                    <li><a href="index.php?tag_id=<?= $tag['id'] ?>"><?= htmlspecialchars($tag['name']) ?></a></li>
                <?php endwhile; ?>
            </ul>
        </div>
    </div>
</body>
</html>
