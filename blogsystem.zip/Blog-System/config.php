<?php
include 'includes/db_connect.php';


$sql = " INSERT INTO `users`( `username`, `password`, `email`, `role`) VALUES ('Brat','admin@2','e@gmail.com','admin') ";
if ($conn -> query($sql) === TRUE){
    echo "<br> New user Update was successful";
 } else{
    echo '<br>ERROR '.$sql . '  '. $conn -> error;
 }
?>